STATIC DRUPAL HANDOFF — Can your AI find another way?

1. Set the Drupal post title to: Can your AI find another way?
2. Paste basic-html.html into the body editor in HTML/source mode.
3. Upload the five PNGs from figures/ using the editor. Replace each image at
   its matching caption, or replace its relative src with Drupal's uploaded URL.
   Filenames follow the figure numbers in the article. Keep the supplied alt text.
   Use the editor's normal image sizing/alignment options for your site's layout.
4. Upload paper.pdf and replace the relative paper.pdf link in “our recent study”
   with its Drupal URL, or use your existing public link to the same paper.
5. Save the draft and check the images and study link in Drupal's preview.

Only ordinary headings, paragraphs, emphasis, quotations, links and images are
used. No custom CSS, JavaScript, embedded widget, interactive control, or theme
configuration is needed. Captions are ordinary paragraphs below the images.

basic-html.html is the body fragment to paste; it deliberately has no page title
or document wrapper. preview.html is a complete, unstyled local preview: extract
the entire ZIP, then open it in a browser. Relative image/PDF paths work locally;
replace those paths with the uploaded URLs in Drupal. The preview uses browser
defaults; Drupal supplies the final typography and image layout. Images have a
680-pixel display width in the HTML and retain their original full resolution.

REVISION
The author’s revised TL;DR now leads the post. Graph coloring is the only worked
puzzle, with its solution immediately visible. The four other puzzle walkthroughs
and their exhaustive solution lists have been removed. All open/close/reveal,
choice-selection and game instructions have been removed. The study's reported
numbers and four research/explanatory graphics are retained. Figure files have
been renamed to match their article numbers. All five figures are separate PNGs.

This package is independent of the earlier interactive Drupal package. It does
not require any of that package's CSS or scripts. Keep this static HTML as the
source for subsequent editorial changes.
