# ICLR submission — Overleaf project

Measuring and Mitigating Solution Mode Collapse in RLVR

This is the full ICLR manuscript, including the appendix. The MATH-AI workshop
version is packaged separately by
`ops/package_mathai2026_overleaf.py`.

## Upload and compile

1. In Overleaf, choose **New Project -> Upload Project** and upload this whole ZIP.
2. Set the **Main document** to `main.tex` and the **Compiler** to **pdfLaTeX**.
3. Click **Recompile**. The bibliography is built automatically with BibTeX.

Everything needed to compile is included: the manuscript and its full appendix,
every figure PDF, every generated results table fragment, the provider icons,
the bibliography and its style, and the local LaTeX style files. The project
needs only standard TeX Live packages. It requires no repository checkout, no
Python, no data download, no figure regeneration, and no shell escape.

`reference/compiled-main.pdf` is the PDF produced from these exact sources in
the repository; compare against it if your TeX Live version shifts line
wrapping. It was checked with pdfLaTeX (TeX Live 2020) and BibTeX. Select
TeX Live 2020 in Overleaf project settings to match the tested version.

`main.bbl` is included, so the bibliography renders on the very first
compile even before BibTeX has run.

## Where to edit

- `main.tex`: the entire manuscript, including the appendix.
- `example_paper.bib`: bibliography entries.
- `figures/`: figure PDFs, each alongside the JSON provenance record it was
  generated with. LaTeX reads only the PDFs.
- `results/`: generated table fragments pulled in by `\input`. These are
  generated copies in the repository - edit them there and re-export rather
  than by hand here.
- `icons/`: provider logos used in the hosted-model figures and tables.
- `iclr2027_conference.sty`, `iclr2027_conference.bst`: the official style,
  unchanged.
- `fancyhdr.sty`, `natbib.sty`, `wrapfig.sty`: local copies of common packages,
  included so the layout matches the locally tested build exactly.
- `latexmkrc`: pdfLaTeX build defaults; no custom build scripts are needed.
- `PACKAGE_MANIFEST.json`: every packaged file with its SHA-256.

Research-code paths printed in the supplement identify the original
experiments; they are not files required to compile this paper.

Upload instructions: https://www.overleaf.com/learn/latex/Kb/Uploading_a_project
