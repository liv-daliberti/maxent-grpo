# MATH-AI 2026 — Overleaf project

Mode Collapse in RLVR & ModeBench

## Upload and compile

1. In Overleaf, choose **New Project → Upload Project** and upload the whole ZIP.
2. Set the **Main document** to `main.tex` and the **Compiler** to **pdfLaTeX**.
3. Click **Recompile**. The bibliography is built automatically with BibTeX.

All manuscript sources, the full appendix, all figure PDFs, input tables,
bibliography, bibliography style, and local LaTeX style files are included.
The project needs only standard TeX Live packages. It requires no repository
checkout, Python scripts, data downloads, external figure generation, or shell
escape to compile.

The supplied `reference/compiled-main.pdf` is the reviewed PDF for comparison.
The expected layout is four main-content pages, Figure 1 on page 1, references
starting on page 5, and the complete supplement after the references.
Compilation was checked locally with pdfLaTeX (TeX Live 2020) and BibTeX via
latexmk. If a different TeX Live version changes line wrapping, compare against
the reference PDF; select TeX Live 2020 in project settings if available to
match the locally tested version.

## Where to edit

- `main.tex`: title, anonymous author placeholder, abstract, and four-page paper.
- `preamble.tex`: packages, formatting, macros, and workshop footer.
- `appendix.tex`: supplementary material and proofs.
- `example_paper.bib`: bibliography entries.
- `figures/`: figures and their existing JSON provenance.
- `results/`: input table fragments and existing result snapshots.
- `neurips_2026.sty`: the official workshop style, unchanged.
- `latexmkrc`: pdfLaTeX build defaults; no custom build scripts are needed.
- `PACKAGE_MANIFEST.json`: packaged-file hashes and original-source hashes.

This package remains in anonymous submission mode. For an accepted
camera-ready version, insert `\def\mathaicameraready{1}` before
`\input{preamble}` in `main.tex`, replace the anonymous author placeholder,
and update `pdfauthor` in `preamble.tex`.

The document-class declaration is placed directly in `main.tex` so Overleaf
recognizes the entry point. This only relocates the declaration from the
preamble; the manuscript text, figures, results, and formatting are unchanged.
Research-code paths printed in the supplement identify the original experiments;
they are not files required to compile this paper.

Upload instructions: https://www.overleaf.com/learn/latex/Kb/Uploading_a_project
